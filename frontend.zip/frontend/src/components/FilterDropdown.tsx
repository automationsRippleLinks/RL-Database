import { useMemo, useState } from 'react';
import { Check, ChevronDown, X } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';



export interface DropdownOption {
  value: string;
  label: string;
  /** Draws the brand mark beside the label — the Platform list only. */
  icon?: LucideIcon;
}

interface FilterDropdownProps {
  label: string;
  options: DropdownOption[];
  selected: string[];

  onChange: (values: string[]) => void;
  /** Adds the in-popover search box: Brand, Category, State and City use it. */
  searchable?: boolean;
  open?: boolean;
  onToggle?: () => void;
  /** Shown in place of the option list when there is no vocabulary at all. */
  emptyHint?: string;
  allowAny?: boolean;
  inline?: boolean;
  icon?: LucideIcon;
  // platformIcons?: boolean;
  iconButtons?: boolean;
  /** Text on the button when nothing is picked. Filters say "Any"; a form field says "None". */
  emptyText?: string;
  /** Shows each pick as a small chip with a cross to remove it, and keeps the closed box blank. Forms use it. */
  chips?: boolean;

  /** The form shows its own label above the field. */
  hideLabel?: boolean;

}

/**
 * One list filter in the rail.
 *
 * Deliberately NOT built on components/ui/popover: Radix portals its content to
 * the body, and the handoff requires these popovers to render inline, directly
 * beneath their field and inside the rail's own 214px, so a long City list never
 * floats over the results table. That constraint is the whole reason this is a
 * plain absolutely-positioned div — the list scrolls inside itself instead.
 *
 * Open/closed is owned by the parent because the rail allows exactly one open
 * popover; `data-rp-pop="menu"` is what the shell's outside-click listener tests.
 */
export function FilterDropdown({
  label,
  options,
  selected,
  onChange,
  searchable = false,
  open = false,
  onToggle,
  emptyHint,
  allowAny = true,
  inline = false,
  icon: Icon,
  hideLabel = false,
  emptyText = 'Any',
  chips = false,

}: FilterDropdownProps) {
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!searchable || !needle) return options;
    return options.filter((option) => option.label.toLowerCase().includes(needle));
  }, [options, query, searchable]);

  const searching = searchable && query.trim().length > 0;
  const directInline = inline && !onToggle;

  const summary =
    chips
      ? ''
      : selected.length === 0
        ? emptyText
        : selected.length === 1
          ? (options.find((option) => option.value === selected[0])?.label ?? selected[0])
          : `${selected.length} selected`;


  const toggleValue = (value: string) => {
    onChange(
      selected.includes(value) ? selected.filter((item) => item !== value) : [...selected, value],
    );
  };




  return (
    <div className="shrink-0">
      {!directInline && (
        <>
          {inline ? (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                onToggle?.();
              }}

              className={cn(
                "flex w-full items-center justify-between rounded-lg px-2 py-2 text-left text-[12px] font-semibold text-rp-text transition-colors",
                open
                  ? "bg-rp-surface2"
                  : "bg-rp-surface hover:bg-rp-surface2"
              )}
            >
              <span className="flex items-center gap-2">
                {Icon && <Icon className="size-4 text-rp-muted" />}
                <span>{label}</span>
              </span>
              <ChevronDown
                className={cn(
                  'size-3.5 transition-transform',
                  open && 'rotate-180',
                )}
              />
            </button>
          ) : (
            <>
              {!hideLabel && (
                <span className="mb-1 block text-[11px] font-semibold text-rp-muted">
                  {label}
                </span>
              )}
              {chips && (
                <div
                  role="button"
                  tabIndex={0}
                  onClick={() => {
                    setQuery('');
                    onToggle?.();
                  }}
                  onKeyDown={(event) => {
                    if (event.target === event.currentTarget && (event.key === 'Enter' || event.key === ' ')) {
                      event.preventDefault();
                      setQuery('');
                      onToggle?.();
                    }
                  }}
                  className={cn(
                    'flex min-h-9 w-full cursor-pointer items-center gap-1.75 rounded-[9px] border bg-rp-surface2 px-2 py-1.5 text-xs transition-colors',
                    open ? 'border-rp-primary' : 'border-rp-border',
                  )}
                >
                  <div className="flex min-w-0 flex-1 flex-wrap gap-1.5">
                    {selected.map((value) => {
                      const text = options.find((option) => option.value === value)?.label ?? value;
                      return (
                        <span
                          key={value}
                          className="inline-flex max-w-full items-center gap-1 rounded-full bg-rp-primary-soft py-0.5 pl-2.5 pr-1 text-[11.5px] font-semibold text-rp-primary"
                        >
                          <span className="truncate">{text}</span>
                          <button
                            type="button"
                            aria-label={`Remove ${text}`}
                            onClick={(event) => {
                              event.stopPropagation();
                              toggleValue(value);
                            }}
                            className="flex size-4 shrink-0 cursor-pointer items-center justify-center rounded-full hover:bg-rp-surface2"
                          >
                            <X className="size-3" strokeWidth={2.6} />
                          </button>
                        </span>
                      );
                    })}
                  </div>
                  <ChevronDown className={cn('size-3.5 shrink-0 opacity-75 transition-transform', open && 'rotate-180')} />
                </div>
              )}
              {!chips && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery('');
                    onToggle?.();
                  }}
                  title={`${label}: ${selected.length ? selected.join(', ') : emptyText}`}
                  className={cn(
                    'flex w-full items-center gap-1.75 rounded-[9px] border px-2.5 py-2 text-left text-xs transition-colors',
                    'bg-rp-surface2 cursor-pointer',
                    open ? 'border-rp-primary' : 'border-rp-border',
                    selected.length
                      ? 'font-semibold text-rp-text'
                      : 'font-medium text-rp-muted',
                  )}
                >
                  <span className="min-w-0 flex-1 truncate">{summary}</span>

                  <ChevronDown
                    className={cn(
                      'size-3.5 shrink-0 opacity-75 transition-transform',
                      open && 'rotate-180',
                    )}
                  />
                </button>
              )}
            </>
          )}
        </>

      )}



      {
        (open || directInline) && (
          <div
            className={cn(
              'overflow-hidden',
              !inline &&
              'animate-rp-menu mt-1 rounded-[10px] border border-rp-border bg-rp-surface',
              directInline &&
              'rounded-[9px] border border-rp-border bg-rp-surface',
            )}
          >
            {searchable && (
              <div className="px-1.75 pt-1.75">
                <input
                  autoFocus={!inline}
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder={`Search ${label.toLowerCase()}`}
                  aria-label={`Search ${label.toLowerCase()}`}
                  className="w-full rounded-lg border border-rp-border bg-rp-surface2 px-2.25 py-1.75 text-xs outline-none focus-visible:border-rp-primary"
                />
              </div>
            )}

            <div className="rp-scroll flex max-h-54 flex-col gap-px overflow-x-hidden overflow-y-auto p-1.5">
              {/* "Any" is the cleared state rather than an option, so it is checked
                when nothing is selected and hidden while searching — a search is
                a search of the vocabulary, and "Any" is not part of it. */}
              {!inline && allowAny && !searching && (
                <OptionRow
                  label="Any"
                  checked={selected.length === 0}
                  emphasis={false}
                  onClick={() => onChange([])}
                />
              )}

              {visible.map((option) => (
                <OptionRow
                  key={option.value}
                  label={option.label}
                  checked={selected.includes(option.value)}
                  emphasis
                  onClick={() => toggleValue(option.value)}
                />
              ))}

              {visible.length === 0 && (
                <p className="px-1 py-2 text-[11.5px] text-rp-muted">
                  {options.length === 0 ? (emptyHint ?? 'Nothing to filter on yet.') : 'Nothing matches that.'}
                </p>
              )}
            </div>
          </div>
        )
      }
    </div >
  );
}

function OptionRow({
  label,
  checked,
  emphasis,
  onClick,
}: {
  label: string;
  checked: boolean;
  /** "Any" reads as checked but is never highlighted — it is the absence of a filter. */
  emphasis: boolean;
  onClick: () => void;
}) {
  const highlighted = checked && emphasis;

  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      onClick={onClick}
      className={cn(
        'flex w-full cursor-pointer items-center gap-2 rounded-lg px-2.25 py-2 text-left text-[12.5px] transition-colors',
        highlighted
          ? 'bg-rp-primary-soft font-semibold text-rp-primary'
          : 'font-medium text-rp-text hover:bg-rp-surface2',
      )}
    >
      <span
        className={cn(
          'flex size-4 shrink-0 items-center justify-center rounded-full border-[1.5px] transition-colors',
          checked ? 'border-rp-primary bg-rp-primary text-rp-primary-fg' : 'border-rp-box',
        )}
      >
        <Check className={cn('size-2.75', !checked && 'opacity-0')} strokeWidth={3.4} />
      </span>
      <span className="min-w-0 flex-1 truncate">{label}</span>
    </button>
  );
}
