import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  ChevronDown,
  ClipboardList,
  Copy,
  X,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { PlatformMark } from '@/components/PlatformMark';
import { useToast } from '@/components/Toast';
import { ErrorState } from '@/components/states';
import { Skeleton } from '@/components/ui/skeleton';
import { useDismissable } from '@/hooks/useDismissable';
import { MONTH_LABELS, PLATFORM_LABELS } from '@/lib/enums';
import { compact, formatMonthYear, formatNumber, initials, profileUrlFor, formatCurrency, isOlderThanYear } from '@/lib/format';
import { describePlace } from '@/lib/geo';
import { cn } from '@/lib/utils';
import type { CreatorCampaignSummary, CreatorPitchSummary, CreatorDetail } from '@/types/api';
import { useCreatorDetail } from '../queries';
import { deliverablesFor } from './deliverables';
import { Link } from 'react-router-dom';
import { withBackState } from '@/lib/navigation';
import { ExpandableSection } from '@/components/ExpandableSection';
import { DetailDrawer } from '@/components/DetailDrawer';
import { CreatorListsSection } from '@/features/lists/CreatorListsSection';
import { useAuth } from '@/features/auth/useAuth';
import { scoreCreator } from '@/features/analytics/creators/calculations/score';
import { CreatorEditForm } from '@/features/analytics/creators/components/CreatorEditForm';
// The edit form is the Analytics one, so its styles come with it (all classes are prefixed cc-).
import '@/features/analytics/tokens.css';
import '@/features/analytics/creators/styles.css';

/**
 * Must match the `rpDrawerOut` duration in index.css. The panel is unmounted
 * when the exit animation ends, and a shorter value here cuts it off mid-slide.
 */

const EXIT_MS = 185;
// pitches and campaigns show only latest few. the backedn sends them newest first 
const LIST_LIMIT = 10;
type CreatorSection = "campaigns" | "pitches";

/**
 * The creator record, as a panel over the results rather than a page.
 *
 * This replaces the old full profile page. Keeping the list visible behind it is
 * the point: choosing between creators means comparing them, and a navigation
 * that throws away the list you were comparing makes you rebuild it every time.
 */
export function CreatorDrawer({
  creatorId,
  onClose,
}: {
  creatorId: string;
  onClose: () => void;
}) {
  const { copy } = useToast();
  const [closing, setClosing] = useState(false);
  const [dealsOpen, setDealsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<CreatorSection | null>(null);
  const [contactIndex, setContactIndex] = useState({ email: 0, phone: 0 });
  const exitTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const [displayedId, setDisplayedId] = useState(creatorId);
  const swapTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const { data, isPending, isError, error, refetch } = useCreatorDetail(displayedId);
  useCreatorDetail(creatorId);



  // Clicking another row swaps the contents in place. Everything that was
  // "opened" belongs to the creator who was showing, not to the panel — and a
  // close that was already in flight is abandoned, so a click that both
  // dismisses and re-opens lands on the new record instead of unmounting.
  useEffect(() => {
    if (creatorId === displayedId) return;

    clearTimeout(exitTimer.current);   // a row click overrides a pending close
    exitTimer.current = undefined;
    clearTimeout(swapTimer.current);
    swapTimer.current = undefined;

    setClosing(true); // trigger closing animation
    swapTimer.current = setTimeout(() => {
      setDisplayedId(creatorId);
      setClosing(false);
      setDealsOpen(false);
      setActiveSection(null); setContactIndex({ email: 0, phone: 0 });
    }, EXIT_MS);
  }, [creatorId, displayedId]);

  useEffect(() => () => {
    clearTimeout(swapTimer.current);
    clearTimeout(exitTimer.current);
    exitTimer.current = undefined;
    swapTimer.current = undefined;
  }, []);

  const requestClose = useCallback(() => {
    if (exitTimer.current) return;

    clearTimeout(swapTimer.current);
    swapTimer.current = undefined;

    setClosing(true);
    exitTimer.current = setTimeout(onClose, EXIT_MS);

  }, [onClose]);

  // ×, Escape and a click anywhere outside all close it, through the same
  // capture-phase listener every other transient surface uses — except the
  // results themselves, where a click means "show me this one instead".
  useDismissable(['drawer', 'results'], !closing, requestClose);

  return (
    <DetailDrawer
      ariaLabel={data ? `${data.name} — creator record` : "Creator record"}
      closing={closing}

      sidePanel={
        activeSection && data && !isPending && !isError
          ? {
            title: activeSection === "campaigns" ? "Campaigns" : "Pitches",
            count:
              activeSection === "campaigns"
                ? data.campaigns.length
                : data.pitches.length,
            content:
              activeSection === "campaigns" ? (
                <CreatorCampaignList campaigns={data.campaigns} />
              ) : (
                <CreatorPitchList pitches={data.pitches} />
              ),
            onClose: () => setActiveSection(null),
          }
          : null
      }
    >
      {isError ? (
        <div className="flex h-full flex-col">
          <DrawerBar onClose={requestClose} />
          <div className="p-4">
            <ErrorState error={error} onRetry={() => refetch()} />
          </div>
        </div>
      ) : isPending || !data ? (
        <div className="flex h-full flex-col">
          <DrawerBar onClose={requestClose} />
          <div className="space-y-3 p-4.5">
            <Skeleton className="h-11 w-2/3" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-28 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        </div>
      ) : (
        <DrawerBody
          key={data.id}
          detail={data}
          onClose={requestClose}
          dealsOpen={dealsOpen}
          onToggleDeals={() => setDealsOpen((open) => !open)}
          activeSection={activeSection}
          onToggleSection={(section) =>
            setActiveSection((current) =>
              current === section ? null : section
            )
          }
          contactIndex={contactIndex}
          onCycleContact={(kind, length) =>
            setContactIndex((current) => ({
              ...current,
              [kind]: (current[kind] + 1) % length,
            }))
          }
          onCopy={copy}
        />
      )}
    </DetailDrawer>
  );
};

/** The close button alone, for the loading and error states. */
function DrawerBar({ onClose }: { onClose: () => void }) {
  return (
    <div className="flex shrink-0 justify-end border-b border-rp-border px-4.5 py-4.5 ">
      <CloseButton onClose={onClose} />
    </div>
  );
}

function CloseButton({ onClose }: { onClose: () => void }) {
  return (
    <button
      type="button"
      onClick={onClose}
      title="Close"
      aria-label="Close"
      className="flex shrink-0 cursor-pointer rounded-lg p-1 text-rp-muted hover:bg-rp-surface2 hover:text-rp-text"
    >
      <X className="size-4" />
    </button>
  );
}

interface DrawerBodyProps {
  detail: CreatorDetail;
  onClose: () => void;
  dealsOpen: boolean;
  onToggleDeals: () => void;
  activeSection: CreatorSection | null;
  onToggleSection: (section: CreatorSection) => void;
  contactIndex: { email: number; phone: number };
  onCycleContact: (kind: "email" | "phone", length: number) => void;
  onCopy: (text: string, message: string) => void;
}

function DrawerBody({
  detail,
  onClose,
  dealsOpen,
  onToggleDeals,
  activeSection,
  onToggleSection,
  contactIndex,
  onCycleContact,
  onCopy,
}: DrawerBodyProps) {
  const { canEdit } = useAuth();
  const [editing, setEditing] = useState(false);
  const profileUrl = profileUrlFor(detail);
  const deals = deliverablesFor(detail.latest_cost_deliverables);
  // console.log('deliverables', detail.latest_cost_deliverables);
  const coveredText =
    typeof detail.latest_cost_deliverables === "string"
      ? detail.latest_cost_deliverables
      : "";
  const costWhen = formatMonthYear(detail.latest_cost_month, detail.latest_cost_year);
  const stale = isOlderThanYear(detail.latest_cost_month, detail.latest_cost_year);
  const costSource = [detail.latest_cost_source?.replace(/_/g, " "), costWhen]
    .filter(Boolean)
    .join(" · ");

  const emails = [...detail.emails].filter(Boolean) as string[];
  const phones = [...detail.phones].filter(Boolean) as string[];

  // "Worked with us" counts campaigns that ran. A dropped link means they were
  // proposed and cut, which is a different fact and is worth saying separately.
  const ran = detail.campaigns.filter((campaign) => !campaign.is_dropped);
  const dropped = detail.campaigns.filter((campaign) => campaign.is_dropped);

  return (
    <>
      {/* ── header ─────────────────────────────────────────────────────── */}
      <div className="flex shrink-0 items-start gap-3 border-b border-rp-border px-4.5 pt-4.5 pb-3.75">
        <span className="flex size-10.25 shrink-0 items-center justify-center rounded-xl bg-rp-primary-soft text-[13px] font-bold text-rp-primary">
          {initials(detail.name)}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block text-[16px] font-bold tracking-[-0.01em]">
            {detail.name}
          </span>
          <span className="mt-0.75   flex items-center gap-1.5">
            <PlatformMark platform={detail.platform} size={14} />
            {profileUrl ? (
              <a
                href={profileUrl}
                target="_blank"
                rel="noreferrer noopener"
                title={`Open profile on ${PLATFORM_LABELS[detail.platform]}`}
                className="truncate text-xs text-rp-primary hover:underline"
              >
                @{detail.username}
              </a>
            ) : (
              <span className="truncate text-xs text-rp-muted">
                @{detail.username}
              </span>
            )}
            {profileUrl && (
              <IconButton
                title="Copy profile link"
                onClick={() => onCopy(profileUrl, "Profile link copied")}
                icon={Copy}
              />
            )}
          </span>
        </span>
        {canEdit && !editing && (
          <button
            type="button"
            onClick={() => setEditing(true)}
            data-testid="drawer-edit"
            // className="h-9 shrink-0 cursor-pointer rounded-lg border border-rp-border bg-rp-surface2 px-3.5 text-[13px] font-medium text-rp-text hover:bg-rp-box"
            className="h-9 shrink-0 cursor-pointer rounded-lg border border-rp-primary bg-rp-primary px-3.5 text-[13px] font-semibold text-rp-primary-fg hover:opacity-90"
          >
            Edit details
          </button>
        )}
        <CloseButton onClose={onClose} />
      </div>

      {editing ? (
        <div className="min-h-0 min-w-0 flex-1 overflow-y-auto scrollbar-thin">
          {/* cc-root brings the edit form's colours; the drawer keeps its own background. */}
          <div className="cc-root px-4.5 py-4" style={{ background: 'transparent' }}>
            <CreatorEditForm scored={scoreCreator(detail)} mode="edit" onDone={() => setEditing(false)} />
          </div>
        </div>
      ) : (
        /* The shared DetailDrawer now handles the sideways layout. */
        <div className="flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto scrollbar-thin">
          {/* ── stats ────────────────────────────────────────────────────── */}
          <div className="grid shrink-0 grid-cols-2 gap-px bg-rp-border">
            <Stat
              label="Followers"
              value={compact(detail.followers)}
              full={detail.followers}
            />
            <Stat
              label="Avg views"
              value={compact(detail.avg_views)}
              full={detail.avg_views}
            />
            <Stat label="Campaigns with us" value={String(ran.length)} />
            <Stat label="Times pitched" value={String(detail.pitches.length)} />
          </div>

          {/* ── lists ─────────────────────────────────────────────────────── */}
          <CreatorListsSection creatorId={detail.id} />




                   {/* ── latest cost ──────────────────────────────────────────────── */}
          <section className="shrink-0 border-t border-rp-border px-4.5 py-3.75">
            <Eyebrow>Latest cost</Eyebrow>
            {detail.latest_cost != null ? (
              <>
                <div className="flex items-baseline gap-2.5">
                  <span
                    title={costSource || undefined}
                    className={cn(
                      "shrink-0 text-2xl font-bold tracking-[-0.01em] whitespace-nowrap tabular-nums",
                      stale && "text-rp-danger",
                    )}
                  >
                    {formatCurrency(detail.latest_cost)}
                  </span>
                  {detail.cpv != null && (
                    <span
                      title={`₹${formatNumber(detail.latest_cost)} ÷ ${formatNumber(detail.avg_views)} avg views`}
                      className="text-[11.5px] text-rp-muted tabular-nums"
                    >
                      CPV ₹{Number(detail.cpv).toFixed(2)}
                    </span>
                  )}
                </div>

                {costSource && (
                  <span
                    className={cn(
                      "mt-1.5 block text-[11.5px] capitalize",
                      stale ? "text-rp-danger" : "text-rp-muted",
                    )}
                  >
                    {costSource}
                  </span>
                )}

                {coveredText && (
                  <span className="mt-1 block text-[12px]">
                    <span className="text-rp-muted">For </span>
                    {coveredText}
                  </span>
                )}

                {deals.length > 0 && (
                  <>
                    <button
                      type="button"
                      onClick={onToggleDeals}
                      aria-expanded={dealsOpen}
                      className={cn(
                        "mt-3 flex w-full cursor-pointer items-center gap-2 rounded-[10px] border border-rp-border px-2.75 py-2.25 text-xs font-semibold",
                        dealsOpen ? "text-rp-primary" : "text-rp-text",
                      )}
                    >
                      <ClipboardList className="size-3.75 shrink-0" />
                      <span className="flex-1 text-left">
                        Deliverables ({deals.length})
                      </span>
                      <ChevronDown
                        className={cn(
                          "size-3.5 shrink-0 transition-transform",
                          dealsOpen && "rotate-180",
                        )}
                        strokeWidth={2.2}
                      />
                    </button>

                    {dealsOpen && (
                      <div className="mt-2.5 flex flex-wrap gap-2">
                        {deals.map(({ key, label, icon: Icon, quantity, cost }) => (
                          <div
                            key={key}
                            className="flex min-w-0 flex-[0_1_calc(50%-4px)] items-center gap-2.5 rounded-sm border border-rp-border bg-rp-surface2 px-3 py-2.75"
                          >
                            <span className="flex size-7 shrink-0 items-center justify-center rounded-sm bg-rp-primary-soft text-rp-primary">
                              <Icon className="size-3.75" />
                            </span>
                            <span className="min-w-0">
                              <span className="block text-2.75 whitespace-nowrap text-rp-muted">
                                {label}
                                {quantity > 1 && (
                                  <span className="ml-1 tabular-nums">×{quantity}</span>
                                )}
                              </span>
                              <span className="mt-px block text-sm font-bold tabular-nums">
                                {cost > 0 ? formatCurrency(cost) : "in package"}
                              </span>
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}

                <span
                  className={cn(
                    "mt-2.5 block text-[11px]",
                    stale ? "text-rp-danger" : "text-rp-muted",
                  )}
                >
                  {stale
                    ? "This cost is over a year old. Confirm before pitching."
                    : "Confirm before pitching."}
                </span>
              </>
            ) : (
              <span className="text-[12.5px] text-rp-muted">
                No cost on file yet.
              </span>
            )}
          </section>
          {/* ── profile ──────────────────────────────────────────────────── */}
      <section className="shrink-0 border-t border-rp-border px-4.5 py-3.75">
        <Eyebrow>Profile</Eyebrow>
        <div className="flex flex-col gap-2.25">
          <Fact label="Location" value={describePlace(detail.city)} />
          <Fact
            label="Categories"
            value={detail.categories[0] ?? "—"}
            extra={
              detail.categories.length > 1
                ? `+${detail.categories.length - 1}`
                : ""
            }
            extraTitle={`Also: ${detail.categories.slice(1).join(", ")}`}
          />
          <Fact
            label="Languages"
            value={detail.languages.slice(0, 2).join(", ") || "—"}
            extra={
              detail.languages.length > 2
                ? `+${detail.languages.length - 2}`
                : ""
            }
            extraTitle={`Also: ${detail.languages.slice(2).join(", ")}`}
          />
          <Fact label="Gender" value={detail.gender ?? "—"} />
          <Fact
            label="Worked with us"
            value={
              ran.length
                ? `Yes — ${ran.length} ${ran.length === 1 ? "campaign" : "campaigns"}`
                : dropped.length
                  ? "Proposed but dropped"
                  : "Not yet"
            }
          />
        </div>
      </section>
      {/* ── contact ─────────────────────────────────────────────────── */}
      {(emails.length > 0 || phones.length > 0) && (
        <section className="shrink-0 border-t border-rp-border px-4.5 py-3.75">
          <Eyebrow>Contact</Eyebrow>

          <div className="flex flex-col gap-2.25">
            {emails.length > 0 && (
              <ContactRow
                label="Email"
                values={emails}
                index={contactIndex.email}
                href={(value) => `mailto:${value}`}
                actionTitle="Send an email"
                onCopy={(value) => onCopy(value, "Email copied")}
                onNext={() => onCycleContact("email", emails.length)}
              />
            )}

            {phones.length > 0 && (
              <ContactRow
                label="Phone"
                values={phones}
                index={contactIndex.phone}
                href={(value) => `tel:${value.replace(/\s/g, "")}`}
                actionTitle="Call this number"
                onCopy={(value) => onCopy(value, "Phone number copied")}
                onNext={() => onCycleContact("phone", phones.length)}
              />
            )}
          </div>
        </section>
      )}

      {/* ── campaigns ──────────────────────────────────────────────── */}
      <ExpandableSection
        label="Campaigns"
        count={detail.campaigns.length}
        open={activeSection === "campaigns"}
        onToggle={() => onToggleSection("campaigns")}
      />

      {/* ── pitches ────────────────────────────────────────────────── */}
      <ExpandableSection
        label="Pitches"
        count={detail.pitches.length}
        open={activeSection === "pitches"}
        onToggle={() => onToggleSection("pitches")}
      />

    </div >
      )
}
    </>
  );
}

// Campaign rows displayed in the shared right panel.

// Renders campaign rows without controlling where they appear.
// We can use this inside the shared DetailDrawer side panel later.
//campaign section 
function CreatorCampaignList({
  campaigns,
}: {
  campaigns: CreatorCampaignSummary[];
}) {
  return (
    <>
      {campaigns.slice(0, LIST_LIMIT).map((campaign) => (<CampaignRow
        key={campaign.campaign_id}
        campaign={campaign}
      />
      ))}
      <LatestNote shown={LIST_LIMIT} total={campaigns.length} />
      {campaigns.length === 0 && (
        <p className="pt-1.5 pb-0.5 text-xs text-rp-muted">
          We have not hired this creator yet.
        </p>
      )}
    </>
  );
}
function CreatorPitchList({
  pitches,
}: {
  pitches: CreatorPitchSummary[];
}) {
  if (pitches.length === 0) {
    return (
      <p className="pt-1.5 pb-0.5 text-xs text-rp-muted">
        No pitches for this creator yet.
      </p>
    );
  }
  // pitches expand section 
  return (
    <>
      {pitches.slice(0, LIST_LIMIT).map((pitch) => (
        <Link
          key={pitch.pitch_id}
          to={`/pitches/${pitch.pitch_id}`}
          state={withBackState(window.location).state}
          className="flex items-center gap-6 border-t border-rp-border py-2.25 hover:bg-rp-surface2">          <span className="min-w-0 flex-1">
            <span className="line-clamp-2 text-[12.5px] font-semibold">
              {pitch.campaign_name}
            </span>
            <span className="flex min-w-0 text-[11.5px] text-rp-muted">
              <span className="truncate">{pitch.brand?.name ?? "No brand linked"}</span>
              <span className="shrink-0 whitespace-pre"> · {pitch.pitch_code}</span>
            </span>
          </span>

          <CostTag
            cost={pickCost(pitch.final_cost, "Final cost", pitch.package_cost, "Package cost", "pkg")}
          />
        </Link>
      ))}
      <LatestNote shown={LIST_LIMIT} total={pitches.length} />
    </>
  );
}

interface CostPick {
  value: number;
  /** Full name, shown on hover. */
  label: string;
  /** Tiny prefix, only when this is the fallback cost. */
  short: string | null;
}
/** Final cost first. If it is missing, the fallback cost fills in and says so. */
interface CostPick {
  value: number;
  /** Full name, shown on hover. */
  label: string;
  /** Tiny prefix, only when this is the fallback cost. */
  short: string | null;
}

/** Final cost first. If it is missing, the fallback cost fills in and says so. */
function pickCost(
  primary: number | null | undefined,
  primaryLabel: string,
  fallback: number | null | undefined,
  fallbackLabel: string,
  fallbackShort: string,
): CostPick | null {
  if (primary && primary > 0) return { value: primary, label: primaryLabel, short: null };
  if (fallback && fallback > 0) return { value: fallback, label: fallbackLabel, short: fallbackShort };
  return null;
}

function CostTag({ cost }: { cost: CostPick | null }) {
  if (!cost) {
    return (
      <span className="inline-flex min-w-16 shrink-0 justify-end text-[11.5px] text-rp-faint">
        –
      </span>
    );
  }
  return (
    <span
      aria-label={cost.label}
      className="group/tip relative inline-flex min-w-16 shrink-0 cursor-help justify-end text-[11.5px] font-semibold tabular-nums"
    >
      {cost.short && (
        <span className="mr-1 text-[10px] font-medium text-rp-muted">{cost.short}</span>
      )}
      {formatCurrency(cost.value)}
      <span
        role="tooltip"
        className="pointer-events-none absolute right-0 bottom-full z-50 mb-0.5 border border-rp-muted bg-rp-surface px-2 py-0.5 text-[13px] font-normal whitespace-nowrap text-rp-text opacity-0 group-hover/tip:opacity-100"
      >
        {cost.label}
      </span>
    </span>
  );
}

// showing only latest 
function LatestNote({ shown, total }: { shown: number; total: number }) {
  if (total <= shown) return null;
  return (
    <p className="pt-2 text=[11px] text-rp-muted">
      Showing the latest {shown} of {total}.
    </p>
  );
}

function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <span className="mb-2.75 block text-[10.5px] font-bold tracking-[0.06em] text-rp-muted uppercase">
      {children}
    </span>
  );
}

function Stat({
  label,
  value,
  full,
}: {
  label: string;
  value: string;
  /** The exact number, as a tooltip — the tile shows the compact form. */
  full?: number | null;
}) {
  return (
    <div className="bg-rp-surface px-4 py-3.25">
      <span className="block text-[10.5px] font-semibold tracking-[0.04em] text-rp-muted uppercase">
        {label}
      </span>
      <span
        className="mt-0.75 block text-3.75 font-bold tabular-nums"
        title={full !== null && full !== undefined ? formatNumber(full) : undefined}
      >
        {value}
      </span>
    </div>
  );
}

function Fact({
  label,
  value,
  extra,
  extraTitle,
}: {
  label: string;
  value: string;
  extra?: string;
  extraTitle?: string;
}) {
  return (
    <div className="flex items-baseline gap-3">
      <span className="w-24.5 shrink-0 text-xs text-rp-muted">{label}</span>
      <span className="min-w-0 flex-1 text-[12.5px] font-medium text-pretty">{value}</span>
      {extra && (
        <span
          title={extraTitle}
          className="shrink-0 cursor-help rounded-md border border-dashed border-rp-box px-1.5 py-px text-[10.5px] text-rp-muted"
        >
          {extra}
        </span>
      )}
    </div>
  );
}

/**
 * One contact line, at a fixed 22px.
 *
 * A creator can have three emails and two numbers. Listing them all makes the
 * panel's height depend on how messy one record is; cycling through them in
 * place keeps every creator's drawer the same shape, and the "1/3" says there is
 * more without needing the room to show it.
 */
function ContactRow({
  label,
  values,
  index,
  href,
  actionTitle,
  onCopy,
  onNext,
}: {
  label: string;
  values: string[];
  index: number;
  href: (value: string) => string;
  actionTitle: string;
  onCopy: (value: string) => void;
  onNext: () => void;
}) {
  const position = index % values.length;
  const value = values[position];

  return (
    <div className="flex h-5.5 items-center gap-2.5">
      <span className="w-20.5 shrink-0 text-xs text-rp-muted">{label}</span>
      <a
        href={href(value)}
        title={actionTitle}
        className="min-w-0 flex-1 truncate text-[12.5px] font-medium text-rp-primary hover:underline"
      >
        {value}
      </a>
      <IconButton title={`Copy ${label.toLowerCase()}`} onClick={() => onCopy(value)} icon={Copy} />
      {values.length > 1 && (
        <span className="inline-flex shrink-0 items-center gap-0.75">
          <span className="text-[10px] tabular-nums text-rp-muted">
            {position + 1}/{values.length}
          </span>
          <IconButton
            title={`Next ${label.toLowerCase()} (${position + 1} of ${values.length})`}
            onClick={onNext}
            icon={ArrowRight}
          />
        </span>
      )}
    </div>
  );
}

// const STATUS_STYLE: Record<CampaignStatus, { label: string; icon: LucideIcon; className: string }> = {
//   wip: { label: 'Running', icon: Clock, className: 'text-rp-primary' },
//   completed: { label: 'Done', icon: Check, className: 'text-rp-success' },
//   'on hold': { label: 'On hold', icon: PauseCircle, className: 'text-rp-warn' },
//   scrapped: { label: 'Dropped', icon: XCircle, className: 'text-rp-danger' },
// };

function CampaignRow({ campaign }: { campaign: CreatorCampaignSummary }) {
  const period = `${MONTH_LABELS[campaign.month_name] ?? campaign.month_name} ${campaign.year}`;
  const brand = campaign.brand?.name ?? 'no brand linked';
  const cost = pickCost(campaign.final_cost, 'Final cost', campaign.initial_cost, 'Initial cost', 'init');

  return (
    <Link
      to={`/campaigns/${campaign.campaign_id}`}
      state={withBackState(window.location).state}
      className="flex items-center gap-6 border-t border-rp-border py-2.25 hover:bg-rp-surface2">      <span className="min-w-0 flex-1">

        <span className="line-clamp-2 text-[12.5px] font-semibold">{campaign.campaign_name}</span>        <span className="block truncate text-[11.5px] text-rp-muted">
          {brand} · {period}
          {campaign.is_dropped && ' · Dropped'}
        </span>
      </span>
      <CostTag cost={cost} />
    </Link>
  );
}

function IconButton({
  title,
  onClick,
  icon: Icon,
}: {
  title: string;
  onClick: () => void;
  icon: LucideIcon;
}) {
  return (
    <button
      type="button"
      onClick={(event) => {
        event.stopPropagation();
        onClick();
      }}
      title={title}
      aria-label={title}
      className="flex shrink-0 cursor-pointer rounded-md p-0.75 text-rp-muted hover:bg-rp-surface2 hover:text-rp-text"
    >
      <Icon className="size-3.25" />
    </button>
  );
}