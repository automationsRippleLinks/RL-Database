"""An ingest job's status changes: claim it, finish it, and sweep up stuck ones.

Each step opens its own short session, so a job's status is committed even if the
work in between crashes.
"""

import logging
from typing import Optional, Any
from uuid import UUID
from datetime import datetime, UTC, timedelta

from sqlmodel import select

from app.core.config import settings
from app.core.db import SessionFactory
from app.models.ingest_job import IngestJob, JobStatus, IngestSource
from app.schemas.ingest import RowError
from app.observability.metrics import INGEST_JOBS

log = logging.getLogger(__name__)


async def claim(sf: SessionFactory, job_id: UUID) -> Optional[IngestJob]:
    """Move a queued job to running and return it; None if it isn't ours to run.
    
    None means the job is gone, already running or finished, or another worker is
    claiming it this instant -- so a job enqueued twice still runs once.
    """
    async with sf() as session:
        job = (
            await session.exec(
                select(IngestJob)
                .where(IngestJob.job_id == job_id, IngestJob.status == JobStatus.QUEUED)
                .with_for_update(skip_locked=True)
            )
        ).first()

        if job is None:
            return None

        job.status = JobStatus.RUNNING
        job.started_at = datetime.now(UTC)
        session.add(job)
        await session.commit()
        return job


async def finish(
    sf: SessionFactory,
    job_id: UUID,
    *,
    errors: list[RowError],
    received: int,
    counts: Optional[dict[str, int]] = None,
    message: Optional[str] = None,
    ai_output: Optional[dict[str, Any]] = None,
    ai_usage: Optional[dict[str, Any]] = None,
    system: bool = False
) -> None:
    """Record a running job's outcome and count it in the metrics.
    
    Any error fails the whole job with all write counts at 0, since nothing was
    written. An error on row 0 is about the whole file, so every row counts as
    failed. Only the first MAX_STORED_ERRORS errors are kept. `system` marks the
    failure as ours rather than the sheet's A job that is no longer running (the
    sweep already failed it) is left alone.
    """
    errors = sorted(errors, key=lambda e: (e.row, e.field or ""))
    kept = errors[: settings.MAX_STORED_ERRORS]

    if errors:
        whole_file = any(e.row == 0 for e in errors)
        values: dict[str, Any] = {
            "status": JobStatus.FAILED,
            "failed": received if whole_file else len({e.row for e in errors}),
            "inserted": 0,
            "updated": 0,
            "skipped": 0,
        }
    else:
        values = {"status": JobStatus.SUCCESS, "failed": 0, **(counts or {})}

    values |= {
        "finished_at": datetime.now(UTC),
        "received": received,
        "errors": [e.model_dump() for e in kept],
        "errors_truncated": len(errors) - len(kept),
        "message": message,
    }
    if ai_output is not None:
        values["ai_output"] = ai_output
    if ai_usage is not None:
        values["ai_usage"] = ai_usage

    async with sf() as session:
        job = (
            await session.exec(
                select(IngestJob)
                .where(
                    IngestJob.job_id == job_id, IngestJob.status == JobStatus.RUNNING
                )
                .with_for_update()
            )
        ).first()
        if job is None:
            return
        job.sqlmodel_update(values)
        session.add(job)
        await session.commit()
        reason = "system" if system or any(e.field == "ai" for e in errors) else "data"
        INGEST_JOBS.add(
            amount=1,
            attributes={
                "source": IngestSource(job.source).value,
                "status": values["status"].value,
                "dry_run": job.dry_run,
            }
            | ({"reason": reason} if errors else {}),
        )
        log.info(
            "ingest job %s %s: %s rows, %s errors",
            job_id,
            values["status"].value,
            received,
            len(errors),
        )


async def sweep(sf: SessionFactory) -> list[UUID]:
    """Fail jobs a dead worker left running; return queued ones nobody picked up.
    
    The worker's reconcile task re-enqueues the returned ids; `claim` makes a
    duplicate harmless.
    """
    now = datetime.now(UTC)
    async with sf() as session:
        stale_jobs = (
            await session.exec(
                select(IngestJob).where(
                    IngestJob.status == JobStatus.RUNNING,
                    IngestJob.started_at
                    < now - timedelta(minutes=settings.STALE_RUNNING_MINUTES),
                )
            )
        ).all()

        for j in stale_jobs:
            j.status = JobStatus.FAILED
            j.finished_at = now
            j.message = "The worker stopped while this job was running. Upload again."

            session.add(j)
            INGEST_JOBS.add(
                amount=1,
                attributes={
                    "source": IngestSource(j.source).value,
                    "status": "failed",
                    "dry_run": j.dry_run,
                    "reason": "system",
                },
            )
            log.warning("ingest job %s abandoned by a dead worker", j.job_id)

        # a queued job's started_at is still the time it was queued; claim resets it
        stuck = (
            await session.exec(
                select(IngestJob.job_id).where(
                    IngestJob.status == JobStatus.QUEUED,
                    IngestJob.started_at
                    < now - timedelta(minutes=settings.STALE_QUEUE_MINUTES),
                )
            )
        ).all()
        await session.commit()
        return list(stuck)
