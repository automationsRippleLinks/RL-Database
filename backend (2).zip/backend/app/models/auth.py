"""People who can sign in, and what each may do."""

from typing import Optional
from datetime import datetime, timezone

from sqlmodel import SQLModel, Field, func, Column, DateTime
from pydantic import ConfigDict, field_validator


class User(SQLModel, table=True):
    """A person who signs in with a password or with Google.

    A super admin passes every permission check whatever the can_* / is_admin
    flags say. `is_currently_employed` false switches the account off.
    `hashed_password` is None for Google accounts.
    """

    model_config = ConfigDict(validate_assignment=True)

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: str = Field(unique=True, index=True, nullable=False)
    auth_provider: str = Field(
        default="password",
        nullable=False,
        sa_column_kwargs={"server_default": "password"},
    )

    hashed_password: Optional[str] = Field(default=None, nullable=True)
    is_verified: bool = Field(
        default=False, nullable=False, sa_column_kwargs={"server_default": "false"}
    )
    is_currently_employed: bool = Field(
        default=True, nullable=False, sa_column_kwargs={"server_default": "true"}
    )
    is_superadmin: bool = Field(
        default=False, nullable=False, sa_column_kwargs={"server_default": "false"}
    )
    is_admin: bool = Field(
        default=False, nullable=False, sa_column_kwargs={"server_default": "false"}
    )
    created_at: datetime = Field(
        sa_column=Column(
            DateTime(timezone=True), nullable=False, server_default=func.now()
        ),
        default_factory=lambda: datetime.now(timezone.utc),
    )
    last_activity_at: datetime = Field(
        sa_column=Column(
            DateTime(timezone=True), nullable=False, server_default=func.now()
        ),
        default_factory=lambda: datetime.now(timezone.utc),
    )

    # permissions
    can_ingest: bool = Field(
        default=False, nullable=False, sa_column_kwargs={"server_default": "false"}
    )

    can_edit: bool = Field(
        default=False, nullable=False, sa_column_kwargs={"server_default": "false"}
    )
    
      # the team this person is in (see models/team.py); null = no team yet
    team_id: Optional[int] = Field(
        default=None, foreign_key="team.id", nullable=True, index=True, ondelete="SET NULL"
    )

    @field_validator("email", mode="after")
    @classmethod
    def lowercase_email(cls, v: str) -> str:
        """Store emails trimmed and lowercase, so lookups by email always match."""
        return v.lower().strip()
