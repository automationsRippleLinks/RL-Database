"""Every table model, gathered in one package.

Alembic's env imports SQLModel from here, so loading this file is what puts every
table on the metadata it diffs against.
"""

from sqlmodel import SQLModel
from .link_models import (
    LanguageCreatorLink,
    PitchCreatorLink,
    CategoryCreatorLink,
    CampaignCreatorLink,
    TagCreatorLink,
    BrandCreatorLink,
)
from .pitch import Pitch
from .category import Category
from .language import Language
from .creator import Creator
from .company import Company
from .auth import User
from .campaign import Campaign
from .brand import Brand
from .ingest_job import IngestJob, IngestSource, JobStatus
from .apify_run import ApifyRun, RunTrigger
from .tag import Tag
from .edit_log import EditLog
from .versioned import Versioned
from .team import Team
from .saved_list import SavedList, ListCreator, ListShare, ListTag

# resolving forward references to avoid circular import error
Pitch.model_rebuild()
Category.model_rebuild()
Language.model_rebuild()
Creator.model_rebuild()
Company.model_rebuild()
Campaign.model_rebuild()
Brand.model_rebuild()

__all__ = [
    "LanguageCreatorLink",
    "PitchCreatorLink",
    "CategoryCreatorLink",
    "CampaignCreatorLink",
    "TagCreatorLink",
    "BrandCreatorLink",
    "Tag",
    "Category",
    "Language",
    "Creator",
    "Pitch",
    "Company",
    "User",
    "Campaign",
    "Brand",
    "IngestJob",
    "IngestSource",
    "JobStatus",
    "ApifyRun",
    "RunTrigger",
    "EditLog",
    "Versioned",
    "Team",
    "SavedList",
    "ListCreator",
    "ListShare",
    "ListTag",
    
]
