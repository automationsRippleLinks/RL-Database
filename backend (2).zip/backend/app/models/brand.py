"""Brands: the client names pitches and campaigns are made for."""

from typing import Optional, TYPE_CHECKING

from sqlmodel import Field, Relationship, Index
from sqlalchemy import CheckConstraint
from pydantic import field_validator, ConfigDict

from app.core.config import settings
from .link_models import BrandCreatorLink
from .versioned import Versioned

if TYPE_CHECKING:
    from .company import Company
    from .pitch import Pitch
    from .campaign import Campaign
    from .creator import Creator


class Brand(Versioned, table=True):
    """A brand we pitch to or run campaigns for.
    
    `name` is the lowercase key ingest matches brands by; `display_name` keeps the 
    casing people typed and is what every page shows.
    """
    model_config = ConfigDict(validate_assignment=True)

    __table_args__ = (
        CheckConstraint(
            f"gstin = '' OR gstin ~ '{settings.GSTIN_REGEX}'",
            name="ck_brand_gstin_format",
        ),
        Index(
            "ix_brand_display_name_trgm",
            "display_name",
            postgresql_using="gin",
            postgresql_ops={"display_name": "gin_trgm_ops"},
        ),
    )

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(unique=True, nullable=False)  
    display_name: str = Field(nullable=False)
    gstin: Optional[str] = Field(
        default=None,
        unique=True,
        schema_extra={"placeholder": "27AAAAA1111A1Z1"},
        nullable=True,
    )

    company_id: Optional[int] = Field(default=None, foreign_key="company.id")
    company: Optional["Company"] = Relationship(back_populates="brands")

    pitches: list["Pitch"] = Relationship(back_populates="brand")
    campaigns: list["Campaign"] = Relationship(back_populates="brand")
    creators: list["Creator"] = Relationship(
        back_populates="brands", link_model=BrandCreatorLink
    )

    @field_validator("name", mode="after")
    @classmethod
    def lowercase_name(cls, v: str) -> str:
        """Keep the match key lowercase and trimmed, the way ingest writes it."""
        return v.lower().strip()
