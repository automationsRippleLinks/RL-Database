"""The v1 API: mounts every route module under its URL prefix and docs tag."""

from fastapi import APIRouter

from .health import router as health_router
from .ingest import router as ingest_router
from .auth import router as auth_router
from .search import router as search_router
from .detail import router as detail_router
from .taxonomy import router as taxonomy_router
from .apify import router as apify_router
from .admin import router as admin_router
from .users import router as users_router
from .edits import router as edits_router
from .analytics import router as analytics_router
from .lists import router as lists_router, people_router, creator_lists_router
router = APIRouter()

router.include_router(health_router, prefix="/health", tags=["Health"])
router.include_router(ingest_router, prefix="/ingest", tags=["Ingest"])
router.include_router(auth_router, prefix="/auth", tags=["Auth"])
router.include_router(search_router, prefix="/search", tags=["Search"])
router.include_router(taxonomy_router, prefix="/taxonomy", tags=["Taxonomy"])
router.include_router(detail_router, tags=["Detail"])
router.include_router(apify_router, prefix="/apify", tags=["Apify"])
router.include_router(admin_router, prefix="/admin", tags=["Admin"])
router.include_router(users_router, prefix="/admin/users", tags=["Users"])
router.include_router(edits_router, tags=["Editing"])
router.include_router(analytics_router, prefix="/analytics", tags=["Analytics"])
router.include_router(lists_router, prefix="/lists", tags=["Lists"])
router.include_router(people_router, prefix="/people", tags=["Lists"])
router.include_router(creator_lists_router, prefix="/creators", tags=["Lists"])